<?php
// Verifica si el botón de registrar ha sido presionado
if (!empty($_POST["btnregistrar"])) {

    // Verifica si el campo de nombre no está vacío
    if (!empty($_POST["txtnombre"])) {
        $nombre = $_POST["txtnombre"]; // Captura el nombre ingresado en el formulario

        // Consulta SQL para verificar si el nombre ya existe en la base de datos
        $verificarNombre = $conexion->query("SELECT COUNT(*) AS 'total' FROM cargo WHERE nombre ='$nombre'");
        
        // Si el nombre ya existe, muestra una notificación de error
        if ($verificarNombre->fetch_object()->total > 0) { ?>
            <script>
                $(function notificacion() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "El Usuario <?= $nombre ?> Ya Existe",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php
        } else {
            // Inserta el nuevo nombre en la base de datos
            $sql = $conexion->query("INSERT INTO cargo(nombre) VALUES ('$nombre')");
            
            // Si la inserción es exitosa, muestra una notificación de éxito
            if ($sql == true) { ?>
                <script>
                    $(function notificacion() {
                        new PNotify({
                            title: "Correcto",
                            type: "success",
                            text: "El Usuario <?= $nombre ?> se ha registrado",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php
            } else { // Si hay un error en la inserción, muestra una notificación de error ?>
                <script>
                    $(function notificacion() {
                        new PNotify({
                            title: "Error",
                            type: "error",
                            text: "Error al registrar el usuario",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php
            }
        }
    } else { // Si el campo de nombre está vacío, muestra una notificación de error ?>
        <script>
            $(function notificacion() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Rellene Todos Los Campos",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php
    }?>

    <script>
        // Evita el reenvío del formulario al recargar la página
        setTimeout(() => {
            window.history.replaceState(null, null, window.location.pathname);
        }, 0);
    </script>
    
    <?php
}
?>

