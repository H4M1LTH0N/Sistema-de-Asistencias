<?php
 if (!empty($_POST["btnregistrar"])) {
    if (!empty($_POST["txtnombre"]) && !empty($_POST["txtapellido"]) && !empty($_POST["txtdni"]) && !empty($_POST["txtcargo"])) {
        $nombre = $_POST["txtnombre"];
        $apellido = $_POST["txtapellido"];
        $dni = $_POST["txtdni"];
        $cargo = $_POST["txtcargo"];

        // Habilitar la visualización de errores para depurar
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        // Verificar si el DNI ya existe
        $verificarDNI = $conexion->query("SELECT COUNT(*) AS 'total' FROM empleado WHERE dni='$dni'");
        if ($verificarDNI->fetch_object()->total > 0) { ?>
            <script>
                $(function notificacion() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "El DNI <?= $dni ?> ya está registrado",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php } else {
            // Ejecutar la consulta de inserción
            $sql = $conexion->query("INSERT INTO empleado(nombre, apellido, dni, cargo) VALUES('$nombre', '$apellido', '$dni', '$cargo')");
            
            if ($sql) { ?>
                <script>
                    $(function notificacion() {
                        new PNotify({
                            title: "Correcto",
                            type: "success",
                            text: "Se ha registrado correctamente",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php } else { ?>
                <script>
                    $(function notificacion() {
                        new PNotify({
                            title: "Error",
                            type: "error",
                            text: "Error al registrar",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php }
        }
    } else { ?>
        <script>
            $(function notificacion() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Rellene todos los campos",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php }?>

<script>
    setTimeout(() => {
        window.history.replaceState(null, null, window.location.pathname);
    }, 0);
</script>

<?php
}
?>


