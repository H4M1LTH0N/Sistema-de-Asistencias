<?php
if (!empty($_POST["btnmodificar"])) {  
    if (!empty($_POST["txtnombre"]) && !empty($_POST["txtapellido"]) && !empty($_POST["txtusuario"]) && !empty($_POST["txtid"])) {
        $nombre = $_POST["txtnombre"];
        $apellido = $_POST["txtapellido"];
        $usuario = $_POST["txtusuario"];
        $id = $_POST["txtid"];

        $stmt = $conexion->prepare("UPDATE usuario SET nombre = ?, apellido = ?, usuario = ? WHERE id_usuario = ?");
        $stmt->bind_param("sssi", $nombre, $apellido, $usuario, $id);

        if ($stmt->execute()) { ?>
            <script>
                $(function notificacion() {
                    new PNotify({
                        title: "Éxito",
                        type: "success",
                        text: "El personal fue modificado correctamente",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php } else { ?>
            <script>
                $(function notificacion() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "Error al modificar empleado: <?= $conexion->error ?>",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php }
        $stmt->close();
    } else { ?>
        <script>
            $(function notificacion() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Rellene todos los campos",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php } ?>
    <script>
        setTimeout(() => {
            window.history.replaceState(null, null, window.location.pathname);
        }, 0);
    </script>
<?php
}
?>

