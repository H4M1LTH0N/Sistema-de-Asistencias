<?php
if (!empty($_POST["btnmodificar"])) {  
    if (!empty($_POST["txtclaveactual"]) && !empty($_POST["txtclavenueva"]) && !empty($_POST["txtid"])) {
        $clave = md5($_POST["txtclaveactual"]);
        $nuevaClave = md5($_POST["txtclavenueva"]); 
        $id = $_POST["txtid"];

        $stmt = $conexion->prepare("SELECT password FROM usuario WHERE id_usuario = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $usuario = $result->fetch_object();

        if ($usuario && $usuario->password == $clave) {
            $stmt_update = $conexion->prepare("UPDATE usuario SET password = ? WHERE id_usuario = ?");
            $stmt_update->bind_param("si", $nuevaClave, $id);
            if ($stmt_update->execute()) { ?>
                <script>
                    $(function notificacion() {
                        new PNotify({
                            title: "Éxito",
                            type: "success",
                            text: "El personal fue modificado correctamente",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php } else { ?>
                <script>
                    $(function notificacion() {
                        new PNotify({
                            title: "Error",
                            type: "error",
                            text: "Error al modificar empleado: <?= $conexion->error ?>",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php }
            $stmt_update->close();
        } else { ?>
            <script>
                $(function notificacion() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "Clave actual incorrecta",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php }
        $stmt->close();
    } else { ?>
        <script>
            $(function notificacion() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Rellene todos los campos",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php } ?>
    <script>
        setTimeout(() => {
            window.history.replaceState(null, null, window.location.pathname);
        }, 0);
    </script>
<?php
}
?>
