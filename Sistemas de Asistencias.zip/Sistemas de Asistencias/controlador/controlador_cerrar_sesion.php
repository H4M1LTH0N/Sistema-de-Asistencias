 <?php
       session_start();
       session_destroy();
       header("Location:/Sistemas de Asistencias/vista/login/login.php");
      
?>
    
