<?php
if (!empty($_GET["id"])) {
    $id = $_GET["id"];
    $sql_query = "DELETE FROM empleado WHERE id_empleado = $id";
    $sql = $conexion->query($sql_query);

    if ($sql) { ?>
        <script>
            $(function notificacion() {
                new PNotify({
                    title: "Correcto",
                    type: "success",
                    text: "Eliminado satisfactoriamente",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php } else { ?>
        <script>
            $(function notificacion() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Hubo un problema al eliminar: <?= $conexion->error ?>",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php } 
}
     ?>
