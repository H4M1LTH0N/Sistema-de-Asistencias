<?php
if (!empty($_GET["id"])) {
   $id=$_GET["id"];
   $sql=$conexion->query("DELETE FROM usuario WHERE id_usuario= $id");
    if ($sql==true) {?>
        <script>
            $(function notificacion() {
                new PNotify({
                    title: "Correcto",
                    type: "success",
                    text: "El usuario fue eliminado satisfactoriamente",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php  } else { ?>
        <script>
            $(function notificacion() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Hubo un problema al borrar el ususario <?=$usuario?>",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php  }?>

<script>
    setTimeout(() => {
        window.history.replaceState(null, null, window.location.pathname);
    }, 0);
</script>

<?php
    
}
?>