<?php
if (!empty($_POST["btnmodificar"])) {  
    if (!empty($_POST["txtnombre"])) {
        $nombre = $_POST["txtnombre"];
        $id = $_POST["txtid"];

        // Habilitar la visualización de errores para depurar
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);

        // Verificar si el nombre del cargo ya existe
        $verificarNombre = $conexion->query("SELECT COUNT(*) AS 'total' FROM cargo WHERE nombre='$nombre' AND id_cargo!= $id");
    

        if ($verificarNombre === false) {
            echo "Error en la consulta SQL: " . $conexion->error;
            exit;
        }

        $resultado = $verificarNombre->fetch_object();
        if ($resultado->total > 0) { ?>
            <script>
                $(document).ready(function() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "El Cargo Ya Existe",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php } else {
            // Actualizar nombre del cargo
            $update = $conexion->query("UPDATE cargo SET nombre='$nombre' WHERE id_cargo=$id");

            if ($update === false) {
                echo "Error en la actualización: " . $conexion->error;
                exit;
            }

            if ($update) { ?>
                <script>
                    $(document).ready(function() {
                        new PNotify({
                            title: "Éxito",
                            type: "success",
                            text: "El Cargo fue actualizado correctamente",
                            styling: "bootstrap3"
                        });
                    });
                
            </script>
            <?php } else { ?>
                <script>
                    $(document).ready(function() {
                        new PNotify({
                            title: "Error",
                            type: "error",
                            text: "Error al actualizar el Cargo",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php }
        }
    } else { ?>
        <script>
            $(document).ready(function() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Por favor, rellene todos los campos",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php } ?>

    <script>
        setTimeout(() => {
            window.history.replaceState(null, null, window.location.pathname);
        }, 0);
    </script>

<?php
}
?>
