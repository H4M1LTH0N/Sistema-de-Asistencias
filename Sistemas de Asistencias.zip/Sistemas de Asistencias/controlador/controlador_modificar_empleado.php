<?php
if (!empty($_POST["btnmodificar"]))  { 
    if (!empty($_POST["txtid"]) && !empty($_POST["txtnombre"]) && !empty($_POST["txtapellido"]) && !empty($_POST["txtdni"]) && !empty($_POST["txtcargo"])) {
        $id = $_POST["txtid"];
        $nombre = $_POST["txtnombre"];
        $apellido = $_POST["txtapellido"];
        $dni = $_POST["txtdni"];
        $cargo = $_POST["txtcargo"];
        
        $sql_query = "UPDATE empleado SET nombre='$nombre', apellido='$apellido', dni='$dni', cargo='$cargo' WHERE id_empleado='$id'";
        $sql = $conexion->query($sql_query);

        if ($sql) { ?>
            <script>
                $(function notificacion() {
                    new PNotify({
                        title: "Éxito",
                        type: "success",
                        text: "El personal fue modificado correctamente",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php } else { ?>
            <script>
                $(function notificacion() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "Error al modificar empleado: <?= $conexion->error ?>",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php }
    } else { ?>
        <script>
            $(function notificacion() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Rellene todos los campos",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php } ?>
    <script>
        setTimeout(() => {
            window.history.replaceState(null, null, window.location.pathname);
        }, 0);
    </script>
<?php
}
?>



