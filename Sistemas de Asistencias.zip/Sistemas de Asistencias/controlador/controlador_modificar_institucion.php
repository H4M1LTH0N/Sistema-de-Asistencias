<?php
if (!empty($_POST["btnmodificar"])) {  
    if (!empty($_POST["txtid"])) {
        $id = $_POST["txtid"];
        $nombre = $_POST["txtnombre"];
        $telefono = $_POST["txttelefono"];
        $ubicacion= $_POST["txtubicacion"];
        $ruc = $_POST["txtruc"];
        $sql=$conexion->query("UPDATE empresa SET nombre='$nombre', telefono=$telefono, ubicacion='$ubicacion', ruc=$ruc WHERE id_empresa=$id" );
        if ($sql==true) { ?>
            <script>
                $(document).ready(function() {
                    new PNotify({
                        title: "Éxito",
                        type: "success",
                        text: "Se ha actualizado correctamente",
                        styling: "bootstrap3"
                    });
                });
            
        </script>
        <?php 
            
        } else {?>
            <script>
                $(document).ready(function() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "Error al actualizar ",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php 
            
        }
        
    }else { ?>
            <script>
                $(document).ready(function() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "Error al actualizar ",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php 
            
        } ?>
    <script>
        setTimeout(() => {
            window.history.replaceState(null, null, window.location.pathname);
        }, 0);
    </script>

<?php
}
?>
