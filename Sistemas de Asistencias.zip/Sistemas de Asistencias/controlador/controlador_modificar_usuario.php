<?php
if (!empty($_POST["btnmodificar"])) {  
    if (!empty($_POST["txtnombre"]) && !empty($_POST["txtapellido"]) && !empty($_POST["txtusuario"])) {
        $nombre = $_POST["txtnombre"];
        $apellido = $_POST["txtapellido"];
        $usuario = $_POST["txtusuario"];
        $id = $_POST["txtid"];
        
        $sql = $conexion->query("SELECT COUNT(*) AS 'total' FROM usuario WHERE usuario = '$usuario' AND id_usuario != $id");
        
        if ($sql->fetch_object()->total > 0) {
            ?>
            <script>
                $(document).ready(function() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "El Usuario <?= $usuario ?> Ya Existe",
                        styling: "bootstrap3"
                    });
                });
            </script>
            <?php
        } else {
            $update = $conexion->query("UPDATE usuario SET nombre='$nombre', apellido='$apellido', usuario='$usuario' WHERE id_usuario=$id");
            if ($update) { ?>
                <script>
                    $(document).ready(function() {
                        new PNotify({
                            title: "Éxito",
                            type: "success",
                            text: "Usuario <?= $usuario ?> actualizado correctamente",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php } else { ?>
                <script>
                    $(document).ready(function() {
                        new PNotify({
                            title: "Error",
                            type: "error",
                            text: "Error al actualizar el usuario <?= $usuario ?>",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php }
        }
    } else { ?>
        <script>
            $(document).ready(function() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Por favor, rellene todos los campos",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php }?>

<script>
    setTimeout(() => {
        window.history.replaceState(null, null, window.location.pathname);
    }, 0);
</script>

<?php
}
?>

