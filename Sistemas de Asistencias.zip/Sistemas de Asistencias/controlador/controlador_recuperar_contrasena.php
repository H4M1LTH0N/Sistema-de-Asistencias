<?php
session_start();
include "../../modelo/conexion.php";

if (!empty($_POST["btningresar"])) {
    echo "Formulario enviado<br>";

    if (!empty($_POST["usuario"]) && !empty($_POST["PIN"]) && !empty($_POST["newpassword"])) {
        echo "Campos no están vacíos<br>";

        $usuario = $_POST["usuario"];
        $PIN = md5($_POST["PIN"]); // Encriptar el PIN ingresado para compararlo con el almacenado
        $newpassword = md5($_POST["newpassword"]); // Encriptar la nueva contraseña usando MD5

        echo "Usuario: $usuario<br>";
        echo "PIN (encriptado): $PIN<br>";
        echo "Nueva contraseña (encriptada): $newpassword<br>";

        // Preparar la consulta para verificar el usuario y el PIN encriptado
        $stmt = $conexion->prepare("SELECT * FROM usuario WHERE usuario = ? AND pin = ?");
        if ($stmt) {
            echo "Consulta preparada<br>";
            $stmt->bind_param("ss", $usuario, $PIN);
            $stmt->execute();
            $result = $stmt->get_result();

            // Depuración: Mostrar el número de filas encontradas
            echo "Número de filas encontradas: " . $result->num_rows . "<br>";

            $usuarioObj = $result->fetch_object();

            if ($usuarioObj) {
                echo "Usuario y PIN son correctos<br>";
                $stmt_update = $conexion->prepare("UPDATE usuario SET password = ? WHERE usuario = ?");
                if ($stmt_update) {
                    echo "Consulta de actualización preparada<br>";
                    $stmt_update->bind_param("ss", $newpassword, $usuario);
                    if ($stmt_update->execute()) {
                        echo "Contraseña actualizada<br>";
                        echo '<script>
                            $(document).ready(function() {
                                new PNotify({
                                    title: "Éxito",
                                    type: "success",
                                    text: "La contraseña fue modificada correctamente",
                                    styling: "bootstrap3"
                                });
                            });
                        </script>';
                    } else {
                        echo "Error al ejecutar la consulta de actualización<br>";
                        echo '<script>
                            $(document).ready(function() {
                                new PNotify({
                                    title: "Error",
                                    type: "error",
                                    text: "Error al modificar la contraseña: ' . $conexion->error . '",
                                    styling: "bootstrap3"
                                });
                            });
                        </script>';
                    }
                    $stmt_update->close();
                } else {
                    echo "Error al preparar la declaración SQL para actualizar<br>";
                    echo '<script>
                        $(document).ready(function() {
                            new PNotify({
                                title: "Error",
                                type: "error",
                                text: "Error al preparar la declaración SQL para actualizar",
                                styling: "bootstrap3"
                            });
                        });
                    </script>';
                }
            } else {
                echo "Usuario o PIN incorrecto<br>";
                echo '<script>
                    $(document).ready(function() {
                        new PNotify({
                            title: "Error",
                            type: "error",
                            text: "Usuario o PIN incorrecto",
                            styling: "bootstrap3"
                        });
                    });
                </script>';
            }
            $stmt->close();
        } else {
            echo "Error al preparar la declaración SQL para verificar<br>";
            echo '<script>
                $(document).ready(function() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "Error al preparar la declaración SQL para verificar",
                        styling: "bootstrap3"
                    });
                });
            </script>';
        }
    } else {
        echo "Campos vacíos<br>";
        echo '<script>
            $(document).ready(function() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Rellene todos los campos",
                    styling: "bootstrap3"
                });
            });
        </script>';
    }
    echo '<script>
        setTimeout(function() {
            window.history.replaceState(null, null, window.location.pathname);
        }, 0);
    </script>';
}
?>









