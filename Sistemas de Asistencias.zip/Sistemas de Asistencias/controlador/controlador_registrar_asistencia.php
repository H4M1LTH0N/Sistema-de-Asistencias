<?php
if (!empty($_POST["btnentrada"])) {
    if (!empty($_POST["txtdni"])) {
        $dni = $_POST["txtdni"];
        $consulta = $conexion->query("SELECT COUNT(*) AS 'total' FROM empleado WHERE dni='$dni'");
        $id_result = $conexion->query("SELECT id_empleado FROM empleado WHERE dni='$dni'");
        
        if ($consulta->fetch_object()->total > 0) {
            $fecha = date("Y-m-d H:i:s");
            $id_empleado = $id_result->fetch_object()->id_empleado;

            $consultaFecha = $conexion->query("SELECT entrada FROM asistencia WHERE id_empleado=$id_empleado ORDER BY id_asistencia DESC LIMIT 1");
            $fechaBD = $consultaFecha->fetch_object();

            if ($fechaBD && substr($fecha, 0, 10) == substr($fechaBD->entrada, 0, 10)) {
                echo "<script>
                    $(function() {
                        new PNotify({
                            title: 'Incorrecto',
                            type: 'error',
                            text: 'Ya ha registrado entrada hoy',
                            styling: 'bootstrap3'
                        });
                    });
                </script>";
            } else {
                $sql = $conexion->query("INSERT INTO asistencia (id_empleado, entrada) VALUES ($id_empleado, '$fecha')");
                
                if ($sql === true) {
                    echo "<script>
                        $(function() {
                            new PNotify({
                                title: 'Correcto',
                                type: 'success',
                                text: 'Hola, Bienvenido',
                                styling: 'bootstrap3'
                            });
                        });
                    </script>";
                } else {
                    echo "<script>
                        $(function() {
                            new PNotify({
                                title: 'Incorrecto',
                                type: 'error',
                                text: 'Error al registrar entrada',
                                styling: 'bootstrap3'
                            });
                        });
                    </script>";
                }
            }
        } else {
            echo "<script>
                $(function() {
                    new PNotify({
                        title: 'Incorrecto',
                        type: 'error',
                        text: 'El DNI ingresado no existe',
                        styling: 'bootstrap3'
                    });
                });
            </script>";
        }
    } else {
        echo "<script>
            $(function() {
                new PNotify({
                    title: 'Error',
                    type: 'error',
                    text: 'Ingrese el DNI',
                    styling: 'bootstrap3'
                });
            });
        </script>";
    }
}
?>

<script>
    setTimeout(() => {
        window.history.replaceState(null, null, window.location.pathname);
    }, 0);
</script>
