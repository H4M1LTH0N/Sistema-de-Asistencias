<?php
if (!empty($_POST["btnsalida"])) {
    if (!empty($_POST["txtdni"])) {
        $dni = $_POST["txtdni"];
        $consulta = $conexion->query("SELECT COUNT(*) AS 'total' FROM empleado WHERE dni='$dni'");
        $id_result = $conexion->query("SELECT id_empleado FROM empleado WHERE dni='$dni'");

        if ($consulta && $consulta->fetch_object()->total > 0) {
            $fecha = date("Y-m-d H:i:s");
            $id_empleado = $id_result->fetch_object()->id_empleado;

            $busqueda = $conexion->query("SELECT id_asistencia, entrada, salida FROM asistencia WHERE id_empleado = $id_empleado ORDER BY id_asistencia DESC LIMIT 1");
            
            if ($busqueda && $datos = $busqueda->fetch_object()) {
                $id_asistencia = $datos->id_asistencia;
                $entradaBD = $datos->entrada;
                $salidaBD = $datos->salida;

                if (substr($fecha, 0, 10) != substr($entradaBD, 0, 10)) {
                    echo "<script>
                        $(function() {
                            new PNotify({
                                title: 'Incorrecto',
                                type: 'error',
                                text: 'Primero debes registrar tu entrada',
                                styling: 'bootstrap3'
                            });
                        });
                    </script>";
                } elseif (!empty($salidaBD) && substr($fecha, 0, 10) == substr($salidaBD, 0, 10)) {
                    echo "<script>
                        $(function() {
                            new PNotify({
                                title: 'Incorrecto',
                                type: 'error',
                                text: 'Ya has registrado tu salida para el día de hoy',
                                styling: 'bootstrap3'
                            });
                        });
                    </script>";
                } else {
                    $sql = $conexion->query("UPDATE asistencia SET salida='$fecha' WHERE id_asistencia=$id_asistencia");

                    if ($sql === true) {
                        echo "<script>
                            $(function() {
                                new PNotify({
                                    title: 'Correcto',
                                    type: 'success',
                                    text: 'Adiós, vuelva pronto',
                                    styling: 'bootstrap3'
                                });
                            });
                        </script>";
                    } else {
                        echo "<script>
                            $(function() {
                                new PNotify({
                                    title: 'Incorrecto',
                                    type: 'error',
                                    text: 'Error al registrar salida',
                                    styling: 'bootstrap3'
                                });
                            });
                        </script>";
                    }
                }
            } else {
                echo "<script>
                    $(function() {
                        new PNotify({
                            title: 'Incorrecto',
                            type: 'error',
                            text: 'No se encontró un registro de entrada para hoy.',
                            styling: 'bootstrap3'
                        });
                    });
                </script>";
            }
        } else {
            echo "<script>
                $(function() {
                    new PNotify({
                        title: 'Incorrecto',
                        type: 'error',
                        text: 'El DNI ingresado no existe.',
                        styling: 'bootstrap3'
                    });
                });
            </script>";
        }
    } else {
        echo "<script>
            $(function() {
                new PNotify({
                    title: 'Error',
                    type: 'error',
                    text: 'Ingrese el DNI',
                    styling: 'bootstrap3'
                });
            });
        </script>";
    }
}
?>

<script>
    setTimeout(() => {
        window.history.replaceState(null, null, window.location.pathname);
    }, 0);
</script>

