<?php

if (!empty($_POST["btnregistrar"])) {
    if (!empty($_POST["txtnombre"]) && !empty($_POST["txtapellido"]) && !empty($_POST["txtusuario"]) && !empty($_POST["txtpassword"]) && !empty($_POST["txtPIN"])) {
        $nombre = $_POST["txtnombre"];
        $apellido = $_POST["txtapellido"];
        $usuario = $_POST["txtusuario"];
        $password = md5($_POST["txtpassword"]);
        $PIN = md5($_POST["txtPIN"]);

        $sql = $conexion->query("SELECT COUNT(*) AS total FROM usuario WHERE usuario = '$usuario'");
        $result = $sql->fetch_object();
        
        if ($result->total > 0) { ?>
            <script>
                $(function notificacion() {
                    new PNotify({
                        title: "Error",
                        type: "error",
                        text: "El Usuario <?= $usuario ?> Ya Existe",
                        styling: "bootstrap3"
                    });
                });
            </script>
        <?php } else {
            $registro = $conexion->query("INSERT INTO usuario (nombre, apellido, usuario, password, PIN) VALUES ('$nombre', '$apellido', '$usuario', '$password','$PIN')");
            if ($registro) { ?>
                <script>
                    $(function notificacion() {
                        new PNotify({
                            title: "Correcto",
                            type: "success",
                            text: "El Usuario <?= $usuario ?> se ha registrado correctamente",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php } else { ?>
                <script>
                    $(function notificacion() {
                        new PNotify({
                            title: "Incorrecto",
                            type: "error",
                            text: "Error al registrar Usuario <?= $usuario ?>",
                            styling: "bootstrap3"
                        });
                    });
                </script>
            <?php }
        }
    } else { ?>
        <script>
            $(function notificacion() {
                new PNotify({
                    title: "Error",
                    type: "error",
                    text: "Rellene Todos Los Campos",
                    styling: "bootstrap3"
                });
            });
        </script>
    <?php } ?>

<script>
    setTimeout(() => {
        window.history.replaceState(null, null, window.location.pathname);
    }, 0);
</script>

<?php
}
?>

