<?php

session_start(); // Inicia una nueva sesión o reanuda la sesión existente

// Verifica si el botón de ingresar ha sido presionado
if (!empty($_POST["btningresar"])) {
    
    // Verifica que los campos de usuario y contraseña no estén vacíos
    if (!empty($_POST["usuario"]) && !empty($_POST["password"])) {
        $usuario = $_POST["usuario"]; // Captura el nombre de usuario ingresado
        $password = md5($_POST["password"]); // Encripta la contraseña usando MD5
        
        // Prepara una consulta SQL para seleccionar el usuario con las credenciales dadas
        $stmt = $conexion->prepare("SELECT * FROM usuario WHERE usuario = ? AND password = ?");
        $stmt->bind_param("ss", $usuario, $password); // Asigna los valores de usuario y contraseña
        $stmt->execute(); // Ejecuta la consulta
        $result = $stmt->get_result(); // Obtiene el resultado de la consulta
        
        // Verifica si se encontró un usuario con las credenciales dadas
        if ($datos = $result->fetch_object()) {
            // Establece variables de sesión con los datos del usuario
            $_SESSION["nombre"] = $datos->nombre;
            $_SESSION["apellido"] = $datos->apellido;
            $_SESSION["id"] = $datos->id_usuario;
            
            // Redirige al usuario a la página de inicio
            header("Location: ../inicio.php");
        } else {
            // Muestra un mensaje de error si las credenciales son incorrectas
            echo "<div class='alert alert-danger'>Usuario o Contraseña inválida</div>";
        }
    } else {
        // Muestra un mensaje de error si los campos están vacíos
        echo "<div class='alert alert-danger'>Los campos están vacíos</div>";
    }
}
?>


