<?php
$conexion=new mysqli("localhost", "root","","BaseDeDatos","3306");
$conexion->set_charset("utf8");
date_default_timezone_set("America/Caracas");


?>